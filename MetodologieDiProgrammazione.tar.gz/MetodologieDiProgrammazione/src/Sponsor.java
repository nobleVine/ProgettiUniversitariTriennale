
public interface Sponsor {
	
	public String getNameS();
	public double getInvestment();

}

