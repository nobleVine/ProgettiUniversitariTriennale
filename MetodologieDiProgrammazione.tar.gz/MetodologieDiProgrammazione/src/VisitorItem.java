
public interface VisitorItem {
	
	// Visitor
	
	public void visitLeaf(Leaf leaf);
	public void visitPackage(Package pack);
			
}
