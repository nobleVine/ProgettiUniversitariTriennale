
public interface Supporter {
	
	public String getNameSupporter();
	public String getSurnameSupporter();
	public int getAge();
	public String getUsername();
	public String getPassword();
	
}
