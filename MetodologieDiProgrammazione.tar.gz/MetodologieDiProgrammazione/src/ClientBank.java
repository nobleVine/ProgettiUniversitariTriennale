
public interface ClientBank {
	
	public int getBankAccount();
	public int getCreditCard();
	public double getCash();
	public void setCash(double cash);
	
}
