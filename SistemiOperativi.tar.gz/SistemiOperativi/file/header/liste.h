#ifndef LISTE_H_
#define LISTE_H_

#include "utility.h"

Persona* creaLista (int, int, int);
Persona* aggiungiAllaLista (int, int, int, bool);
Persona* rimuoviPersona ();
Persona* prendiLaPrimaPersona ();
int eliminaDalSistema (int, char*);
int pesoTotaleDellaLista ();
	
#endif




