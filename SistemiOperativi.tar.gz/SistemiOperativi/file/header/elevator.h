#ifndef ELEVATOR_H_
#define ELEVATOR_H_

#include "generale.h"		
#include "liste.h"

char arrayDati[100];
char nomeDelFileDiLog[30];													
Persona* pers = NULL;																	
int pianoAttuale = 0;																	
int tempoRimasto = 0;																
int pidProcesso = 0;																			
int clientFd = 0;
int serverLen = 0;
int risultatoFunzione = 0;													
struct sockaddr_un serverUNIXAddress;												
struct sockaddr* serverSockAddrPtr;

int aggiungiPersona (int);				// Serve per aggiungere persone all'ascensore.
void richiestaDiConnessione(char*);		// Funzione che serve all'ascensore per connettersi ai piani ed inviare loro comandi.
	
#endif