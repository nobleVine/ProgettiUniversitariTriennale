#ifndef GENERALE_H_
#define GENERALE_H_

#define DEFAULT_PROTOCOL 0														 
#define EXIT_SUCCESS 0
#define EXIT_FAILURE 1
#define NONDEFINITO -1 

#include "utility.h"

typedef struct Persona {
	int iPeso; 													// Record del nodo Persona composto da: peso, piano di partenza e piano di arrivo.
	int iPianoPartenza;
	int iPianoDestinazione; 									 
	struct Persona *next; 										// Puntatore.
} Persona;

int leggiLinea (int, char, char*);					
void scriviSuFile (char*, char*);								// Scrive su file una stringa in modalità m e restituisce il numero dei caratteri scritti.
Persona* creazionePersona (int, int, int);						// Crea un nodo di tipo persona (ovvero crea una persona).
int tempoTrascorso ();											// Funzione usata per prendere il tempo attuale.
char* dataEora ();												// Restituisce data e ora in una stringa.
char* conversionePeso (int);									// Converte il peso di una persona nel tipo di persone.
void totalePersoneTrasportate (char*);							// Restituisce il numero totale di persone trasportate dall'ascensore.
void stampaLogSulTerminale (char*);								// Scrive sul terminale il file di log.
void inizializzazioneRandom();									// Funzione per random migliorato.
time_t inizializzazioneTempo();									// Inizializzazione del tempo per prendere poi il tempo.
void inizializzazioneFileDiLog();
void controlloOpen(int);										// Funzioni per robustezza del codice.
void controlloWrite(int);
void controlloClose(int);

#endif