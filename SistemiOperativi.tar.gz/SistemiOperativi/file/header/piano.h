#ifndef PIANO_H_
#define PIANO_H_

#include "generale.h"																	
#include "liste.h"

char arrayDati[120];
Persona* pers = NULL;
char nomeDelFileDiLog[70];																	
int risultatoFunzione = 0;

void gestoreProcessoFiglio (int);
void generatorePersone (char*, int, int, int, int, int); // Funzione che genera le persone.

#endif