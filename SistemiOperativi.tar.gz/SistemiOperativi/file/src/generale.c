#include "generale.h"
#include "liste.h"

#define MAXDATA 35	// Macro utile per la lunghezza massima della data.

char arrayPerStringhe[120];	// Buffer di supporto per le stringhe.

int leggiLinea (int fd, char term, char *str) {

  	int risultatoFunzione = 0;														

  	do {

    	risultatoFunzione = read (fd, str, 1);										

  	} while (risultatoFunzione > 0 && *str++ != term);								
	
	*(str - 1) = '\0';   															

	return ( risultatoFunzione > 0 ); 												

}

void scriviSuFile (char *nomeDelFileDiLog, char *arrayDati) {

		int risultatoClose = 0;
		int fd = 0;
		int risultatoFunzione = 0;

		fd = open (nomeDelFileDiLog, O_APPEND | O_WRONLY);	// Apro il file di log col puntatore aggiornato.

		controlloOpen(fd);

		risultatoFunzione = write(fd, arrayDati, strlen(arrayDati));	// Scrittura nel file di log.

		controlloWrite(risultatoFunzione);

		risultatoClose = close(fd);

		controlloClose(risultatoClose);

}	

void inizializzazioneRandom() {

	static bool inizializzato = false;												
	
	if (!inizializzato) {		// Inizializzazione più efficiente per la generazione casuale di interi.
		srand(time(NULL));															
		inizializzato = true;														
	}

}

Persona* creazionePersona (int p, int part, int arrivo) {

	inizializzazioneRandom();

	Persona *pers = (Persona*) malloc (sizeof(Persona));	// Allocazione di spazio in memoria per una persona.
	
	if (pers == NULL) {																
		printf("\nLa persona non è stata creata\n");								
		return NULL;																
	}
	
	if (arrivo == NONDEFINITO) { // Inizializzazione del piano di arrivo ( deve essere diverso da quello di partenza).
		arrivo = rand() % 4;														
		while (arrivo == part) {													
			arrivo = rand() % 4;													
		}
	}
		
	pers -> iPeso = p;	//Inizializzazione Persona															
	pers -> iPianoPartenza = part;												
	pers -> iPianoDestinazione = arrivo;															
	pers -> next = NULL;																
	
	return pers;
	
}

time_t inizializzazioneTempo () {

	static time_t tempoIniziale; // Inizializzazione statica per il tempo.
	
	if (tempoIniziale == 0) {																
		tempoIniziale = time (NULL); // Inizializzazione.
	}

	return tempoIniziale;

}

int tempoTrascorso() {

	time_t tempoIniziale = inizializzazioneTempo();
	int tempoFinale = time(NULL) - tempoIniziale;

	return tempoFinale;		// Viene ritornato il tempo attuale meno quello iniziale.

} 

char* dataEora() {

	char *mesi[] = {"Gennaio", "Febbraio", "Marzo", "Aprile", "Maggio", "Giugno", "Luglio", "Agosto", "Settembre", "Ottobre", "Novembre", "Dicembre"};
	char sOra[MAXDATA];
	time_t now;
	now = time (NULL);
	struct tm* ora;
	ora = localtime(&now);
	sprintf(sOra, "%d %s %d %d:%d:%d", ora -> tm_mday, mesi[ora -> tm_mon], ora -> tm_year + 1900, ora -> tm_hour, ora -> tm_min, ora -> tm_sec);
	strcpy(arrayPerStringhe, sOra);
	return arrayPerStringhe;

}

char *conversionePeso (int iPeso) {	// Converte il peso di una persona nel tipo.

	switch (iPeso) {
		
		case 40: return "Bambino";
				 break;
		
		case 80: return "Adulto";
				 break;	
		
		case 100:return "Addetto Alla Manutenzione";
				 break;
		
		case 90: return "Addetto Alla Consegna";
				 break;
		
		default:
				 break;
	
	}

}

void totalePersoneTrasportate (char *nomeDelFileDiLog) {	// Restituisce il numero di persone trasportate dall'ascensore.

	int contBambiniTrasportati = 0;	// Contatori dei singoli tipi di persona.									
	int contAdultiTrasportati = 0;
	int contAddettiAllaManutenzioneTrasportati = 0;
	int contAddettiAllaConsegnaTrasportati = 0;
	int risultatoClose = 0;
	int fd = 0;
	
	fd = open (nomeDelFileDiLog, O_RDONLY);

	controlloOpen(fd);
	
	while (leggiLinea (fd, '\n', arrayPerStringhe)) {						// Finche' non e' terminato il file.
		if (strstr(arrayPerStringhe, "[SCESO]") != NULL) {					// Se e' stato trasportato
			if (strstr(arrayPerStringhe, "Bambino") != NULL) {				// Conteggio delle linee con certe caratteristiche.
				contBambiniTrasportati++;
			} else if (strstr(arrayPerStringhe, "Adulto") != NULL) {
				contAdultiTrasportati++;
			} else if (strstr(arrayPerStringhe, "Manutenzione") != NULL) {
				contAddettiAllaManutenzioneTrasportati++;
			} else if (strstr(arrayPerStringhe, "Consegna") != NULL) {
				contAddettiAllaConsegnaTrasportati++;
			}
		}
	}

	risultatoClose = close(fd);

	controlloClose(risultatoClose);
	// Scrittura sul file di log del resoconto finale.
	sprintf(arrayPerStringhe, "\nEsecuzione terminata!\nRiassunto attivita' di trasporto:\nBambini %d\nAdulti %d\nAddetti alla manutenzione %d\nAddetti alla consegna %d\n", contBambiniTrasportati, contAdultiTrasportati, contAddettiAllaManutenzioneTrasportati, contAddettiAllaConsegnaTrasportati);
	scriviSuFile(nomeDelFileDiLog, arrayPerStringhe);
	
}

void stampaLogSulTerminale (char *nomeDelFileDiLog) {														// Funzione che scrive sul terminale il file di log.

	int risultatoClose = 0;
	int fd = open (nomeDelFileDiLog, O_RDONLY);

	controlloOpen(fd);

	printf("\n");

	while (leggiLinea (fd, '\n', arrayPerStringhe)) {
												// Finche' non e' terminato il file.
		printf("%s", arrayPerStringhe);															
		printf("\n");																
	
	}

	risultatoClose = close(fd);

	controlloClose(risultatoClose);

	printf("\n");

}


void inizializzazioneFileDiLog (char *nomeDelFileDiLog) {

	int fdFileDiLog = 0;
	int risultatoClose = 0;
	fdFileDiLog = open(nomeDelFileDiLog, O_TRUNC);
	controlloOpen(fdFileDiLog);
	risultatoClose = close(fdFileDiLog);
	controlloClose(risultatoClose);

}

void controlloOpen( int risultatoFunzione ) {		// Funzioni di controllo per le system call ( robustezza codice ).

	if ( risultatoFunzione == -1) {
	
		printf("Errore nell'apertura del file\n");
	
	}

}

void controlloWrite (int risultatoFunzione) {

	if ( risultatoFunzione == -1) {

		printf("\nErrore nella write\n");

	}

}

void controlloClose (int risultatoClose) {

	if ( risultatoClose == -1 ) {

		printf("\nErrore nella chiusura del file\n");
	
	}

}

