#include "piano.c"

int main (void) {

	int serverFd = 0;
	int clientFd = 0;
	int serverLen = 0;
	int clientLen = 0;									
	int risultatoClose = 0;
	int risultatoWrite = 0;

	struct sockaddr_un serverUNIXAddress;  											
	struct sockaddr_un clientUNIXAddress; 											
	struct sockaddr* serverSockAddrPtr;    											
	struct sockaddr* clientSockAddrPtr;   											

	serverSockAddrPtr = (struct sockaddr*) &serverUNIXAddress;							
	serverLen = sizeof (serverUNIXAddress);
	clientSockAddrPtr = (struct sockaddr*) &clientUNIXAddress;
	clientLen = sizeof (clientUNIXAddress);

	sprintf(arrayDati, "socket/piano0"); // Pathname socket.								
	serverUNIXAddress.sun_family = AF_UNIX; 										
	strcpy(serverUNIXAddress.sun_path, arrayDati); 									

	sprintf(nomeDelFileDiLog, "logs/logPiano0.txt");										
	
	inizializzazioneFileDiLog(nomeDelFileDiLog);							
	
	signal (SIGCHLD, gestoreProcessoFiglio);	// Gestore per il figlio.
	
	char ID[20];							

	do {										
	
		serverFd = socket(AF_UNIX, SOCK_STREAM, DEFAULT_PROTOCOL);

		if (serverFd == -1) {

			sleep(1);
			printf("Errore nella creazione del Socket\n");

		}

	} while (serverFd == -1);
	
	unlink ("socket/piano0"); 															
	bind(serverFd, serverSockAddrPtr, serverLen); 									
	listen (serverFd, 5); 															
		
	sprintf(arrayDati, "In attesa di connessione sul Socket\n");
	printf("%s\n", arrayDati);
	
	clientFd = accept (serverFd, clientSockAddrPtr, &clientLen);

	if (clientFd == -1) {

		printf("Errore nell'accettazione della richiesta di connessione\n");
		sleep(1);

	}

	leggiLinea (clientFd, '\n', ID);												
	
	risultatoClose = close (clientFd);

	controlloClose(risultatoClose);

	risultatoClose = close (serverFd); 												
	
	controlloClose(risultatoClose);	

	tempoTrascorso();
	
	sprintf(arrayDati, "Inizio tempo di Generazione: %s\n\n", dataEora());
	scriviSuFile(nomeDelFileDiLog, arrayDati); 						
	
	do {

		serverFd = socket(AF_UNIX, SOCK_STREAM, DEFAULT_PROTOCOL);

		if ( serverFd == -1) {

			printf("Errore nella creazione del Socket\n");
			sleep(1);

		}

	} while	(serverFd == -1);					 
	
	risultatoFunzione = fork();	// Duplicazione del processo.

	if (risultatoFunzione != 0) { // Codice padre.
				
		while (true) {

			do {

				clientFd = socket(AF_UNIX, SOCK_STREAM, DEFAULT_PROTOCOL);	
				
				if ( clientFd == -1) {

					printf("Errore nella creazione del Socket\n");
					sleep(1);

				}

			} while (clientFd == -1);
			
			sleep(1);

			if (tempoTrascorso() % 5 == 0) {	// Il padre indica al figlio quando generare persone.

				risultatoFunzione = connect (clientFd, serverSockAddrPtr, serverLen);

					if (risultatoFunzione != -1) {										
						
						sprintf(ID, "piano\n");										
						
						risultatoWrite = write(clientFd, ID, strlen (ID) + 1);

						controlloWrite(risultatoWrite);

				} else {

					printf("\nLa richiesta di connessione non ha avuto successo\n");
				
				}
			
			}

			risultatoClose = close (clientFd);

			controlloClose(risultatoClose);

		}

	} else {	// Codice del figlio. Server che si occupa della gestione della lista.
		
		unlink ("socket/piano0"); 	// Inizializzazione socket.													
		bind(serverFd, serverSockAddrPtr, serverLen); 								
		listen (serverFd, 5); 														
		
		while (true) {
			
			printf("\nPiano in attesa...\n");
			

			do {
				
				clientFd = accept (serverFd, clientSockAddrPtr, &clientLen);	
				
				if (clientFd == -1) {

					printf("Errore nell'accettazione della richiesta di connessione\n");
					sleep(1);

				}

			} while (clientFd == -1);

			risultatoFunzione = leggiLinea (clientFd, '\n', ID);	
			
			if (strcmp (ID, "elevator") == 0) {	// Comando da parte dell'ascensore.									

				risultatoFunzione = leggiLinea(clientFd, '\n', ID);
				
				if (strcmp (ID, "termina") == 0) {		// Per la terminazione.									
					exit(EXIT_SUCCESS);														
				}

				risultatoFunzione = atoi(ID);	// Peso dell'ascensore.
				
				sprintf(arrayDati, "persone\n");								// Specificazione dell'invio delle persone
				
				while (risultatoFunzione >= 0) {									// Fino a quando ci sono persone
					
					pers = prendiLaPrimaPersona();										
					
					if (pers != NULL && (risultatoFunzione - pers -> iPeso) >= 0) {			// Se può entrare in ascensore.
						
						sprintf(arrayDati,"%s%d/%d\n", arrayDati, pers -> iPeso, pers -> iPianoDestinazione); // Peso e piano di destinazione.
						
						risultatoFunzione = risultatoFunzione - pers->iPeso;							// Aggiornamento peso
						
						rimuoviPersona();
						
						personeInCoda0--;												// Aggiornamento delle persone in coda al piano (per la limitazione a 40).
					
					} else {

						break;														
					
					}

				}
				
				risultatoWrite = write (clientFd, arrayDati, strlen (arrayDati) + 1);			// Scrittura delle persone nel socket.
				
				controlloWrite(risultatoWrite);

			} else if (strcmp (ID, "piano") == 0) {									// Il piano genera le persone.
				
				generatorePersone (nomeDelFileDiLog, 10, 15, 40, 60, 0); 
				
			}

			risultatoClose = close (clientFd);
			
			controlloClose(risultatoClose);

		}

	}

}