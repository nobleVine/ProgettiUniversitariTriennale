#include "piano.h"

int personeInCoda0 = 0;	// Variabili che servono a tenere memoria delle persone in coda ai piani (per implementare la limitazione a 40).
int personeInCoda1 = 0;
int personeInCoda2 = 0;
int personeInCoda3 = 0;


void generatorePersone (char *nomeDelFileDiLog, int tempoBambino, int tempoAdulto, int tempoAddettoAllaManutenzione, int tempoAddettoAlleConsegne, int pianoCorrente ) { // Funzione che genera le persone.

	int tempoCorrente = tempoTrascorso();	// Prendo il tempo rispetto all'inizio
	int personeInCodaPianoCorrente = 0;

	switch (pianoCorrente) {
		
		case 0: personeInCodaPianoCorrente = personeInCoda0;
				break;
		
		case 1: personeInCodaPianoCorrente = personeInCoda1;
				break;	
		
		case 2: personeInCodaPianoCorrente = personeInCoda2;
				break;
		
		case 3: personeInCodaPianoCorrente = personeInCoda3;
				break;
		
		default:
                 printf("errore");
				 break;
	
	}
   
    if(personeInCodaPianoCorrente < 40){

	    char messaggio1[70];	// Ulteriore stinga temporanea per data e ora.

		sprintf(messaggio1, "%s", dataEora());	


		if (tempoCorrente % tempoAddettoAllaManutenzione == 0) {	// Addetto Alla Manutenzione.

			pers = creazionePersona(100, pianoCorrente, NONDEFINITO);
			aggiungiAllaLista(100, pianoCorrente, pers -> iPianoDestinazione, false);
			personeInCodaPianoCorrente++;
			sprintf(arrayDati, "[GENERATO] addetto alla manutenzione, %s, destinazione = %d\n", messaggio1, pers -> iPianoDestinazione);
			scriviSuFile(nomeDelFileDiLog, arrayDati);

		}

		if (tempoCorrente % tempoBambino == 0 && personeInCodaPianoCorrente < 40) {	// Bambino.

			pers = creazionePersona(40, pianoCorrente, NONDEFINITO);	// Crea la persona e lo mette nella temporanea
			aggiungiAllaLista(40, pianoCorrente, pers -> iPianoDestinazione, true); // Aggiunge la persona nella lista
			personeInCodaPianoCorrente++;
			sprintf(arrayDati, "[GENERATO] bambino, %s, destinazione = %d\n", messaggio1, pers -> iPianoDestinazione);
			scriviSuFile(nomeDelFileDiLog, arrayDati);	
												
		}

		if (tempoCorrente % tempoAdulto == 0 && personeInCodaPianoCorrente < 40) {	// Adulto.

			pers = creazionePersona(80, pianoCorrente, NONDEFINITO);
			aggiungiAllaLista(80, pianoCorrente, pers -> iPianoDestinazione, true);
			personeInCodaPianoCorrente++;
			sprintf(arrayDati, "[GENERATO] adulto, %s, destinazione = %d\n", messaggio1, pers -> iPianoDestinazione);
			scriviSuFile(nomeDelFileDiLog, arrayDati);

		}

		if (tempoCorrente % tempoAddettoAlleConsegne == 0 && personeInCodaPianoCorrente < 40) {	// Addetto Alle Consegne.

			pers = creazionePersona(90, pianoCorrente, NONDEFINITO);
			aggiungiAllaLista(90, pianoCorrente, pers -> iPianoDestinazione, true);
			personeInCodaPianoCorrente++;
			sprintf(arrayDati, "[GENERATO] addetto alla consegna, %s, destinazione = %d\n", messaggio1, pers -> iPianoDestinazione);
			scriviSuFile(nomeDelFileDiLog, arrayDati);

		}	

    }

        switch (pianoCorrente) {
		
		case 0: personeInCoda0 = personeInCodaPianoCorrente;
				break;
		
		case 1: personeInCoda1 = personeInCodaPianoCorrente;
				break;	
		
		case 2: personeInCoda2 = personeInCodaPianoCorrente;
				break;
		
		case 3: personeInCoda3 = personeInCodaPianoCorrente;
				break;
		
		default:
               	printf("errore");
				break;
	
	}
		printf("Le persone in coda al piano sono %d", personeInCodaPianoCorrente);
	
}

void gestoreProcessoFiglio (int signal ) {

	int pidProcessoFiglio = 0;
	int terminazioneProcessoFiglio = 0;

	pidProcessoFiglio = wait (&terminazioneProcessoFiglio);
	
	sprintf(arrayDati, "\n%s\n", dataEora());
	scriviSuFile(nomeDelFileDiLog, arrayDati);									

	printf("\nIl processo padre verra' terminato.\n");
	
	stampaLogSulTerminale (nomeDelFileDiLog);
	
	exit(EXIT_SUCCESS);

}