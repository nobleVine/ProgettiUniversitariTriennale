#include "generale.h"
#include "liste.h"

Persona *testaDellaLista = NULL;
Persona *nodoCorrente = NULL;
char arrayDatiPerListe[120];

Persona* creaLista (int p, int pianoP, int pianoD) {

	Persona *pers = creazionePersona (p, pianoP, pianoD);					// Allocazione della spazio in memoria per una persona.
	
	if ( pers == NULL ) {	
		return NULL;
	}

	testaDellaLista = nodoCorrente = pers;									// Riassegnazione della testa al nodo corrente.

	return pers;															

}

Persona* aggiungiAllaLista (int p, int pianoP, int pianoD, bool tail) {

	if (testaDellaLista == NULL) {		
															
		return (creaLista (p, pianoP, pianoD));		// Creazione della lista (primo elemento).
	
	}
	
	Persona *pers = creazionePersona (p, pianoP, pianoD);							
	
	if (pers == NULL) {
		return NULL;																
	}
	
	if (tail) {
												// Politica FIFO ( si aggiunge in coda)
		nodoCorrente -> next = pers;			// Nuovo elemento.
		nodoCorrente = pers;		
												// Il nuovo elemento sarà quindi la nuova coda.
	} else {
												// Il questo caso l'elemento viene aggiunto in testa ( USATO ANCHE PER ADDETTO ALLA MANUTENZIONE)
		pers -> next = testaDellaLista;								
		testaDellaLista = pers;
												// Nuovo elemento = Testa di lista.
	}

	return pers;													

}

Persona* rimuoviPersona () {

	Persona *pers = testaDellaLista; 															

	if (testaDellaLista == nodoCorrente) {
																	 
		testaDellaLista = nodoCorrente = NULL;					
	
	} else if (testaDellaLista != NULL) {

		testaDellaLista = testaDellaLista -> next; 		// Assegnazione della nuova testa di lista (elemento successivo visto che quello attuale è stato tolto).
	
	}

	pers -> next = NULL;
														// Il puntatore dell'elemento tolto dalla lista è posto a NULL.
	if (pers != NULL) {

		sprintf(arrayDatiPerListe, "\nLa persona [%d, %d, %d] è stata tolta\n", pers -> iPeso, pers -> iPianoPartenza, pers -> iPianoDestinazione);
		printf("%s\n", arrayDatiPerListe);
	
	}

	return pers; 	
																					
}

Persona* prendiLaPrimaPersona () {		// Politica FIFO.

	if ( testaDellaLista == NULL ) {
		return NULL;
	} else {
		return testaDellaLista;
	}					

}

int eliminaDalSistema (int iPiano, char *FileName) {

	Persona *pers = testaDellaLista;	//Elemento da controllare											
	Persona *pers1 = NULL;				// Variabili d'appoggio.												
	Persona *pers2 = NULL;															
	int iPesoTolto = 0;
	int risultatoFunzione = 0;														
	
	while (pers != NULL) {										
	
		if (pers -> iPianoDestinazione == iPiano) {	
																					
			iPesoTolto = iPesoTolto + pers -> iPeso;								
			pers2 = pers;															
			
			if (pers != testaDellaLista) {													
				pers1 -> next = pers -> next;												
			}	
			
			pers = pers2 -> next;														
			
			if (pers2 == testaDellaLista) {	
																	
				if (pers == NULL) {													
					
					testaDellaLista = nodoCorrente = NULL;												
				
				} else {
																			
					testaDellaLista = pers2 -> next;											
				
				}

			} else if (pers2 == nodoCorrente) {
															
				nodoCorrente = pers1;	
																		
			}

			sprintf(arrayDatiPerListe, "[SCESO] %s, %s, piano %d\n", conversionePeso(pers2 -> iPeso), dataEora(), pers2 -> iPianoPartenza);
			scriviSuFile(FileName, arrayDatiPerListe);						
			
			if (pers1 != NULL) { 

				sprintf(arrayDatiPerListe, "La persona [%d, %d, %d] è scesa dall'ascensore\n", pers2 -> iPeso, pers2 -> iPianoPartenza, pers2 -> iPianoDestinazione);
				printf("%s\n", arrayDatiPerListe);
			
			}
			
			free(pers2);
			pers2 = NULL;

		} else {

			pers1 = pers;																
			pers = pers -> next;														

		}
	}
		
	return iPesoTolto;																

}

int pesoTotaleDellaLista () {	// Peso totale delle persone presenti nella lista.

	Persona *pers = testaDellaLista;															
	int ipeso = 0;															

	while (pers != NULL) {	
																
		ipeso = ipeso + pers -> iPeso;
		pers = pers -> next;								
	
	}

	return ipeso;																	

}
	