#include "elevator.h"	

int aggiungiPersona (int fd) {

	char *persone = NULL;															// Informazioni sul peso e sul piano di arrivo.
	int contPersoneAggiunte = 0;													// Conteggio delle persone salite sull'ascensore.	

	while ( leggiLinea (fd, '\n', arrayDati) ) {									// Finchè ci sono righe da leggere.
		
		if (strcmp (arrayDati, "persone") == 0) continue;						// Viene saltata la riga di comando (un'iterazione dello while).
		
			persone = strtok(arrayDati, "/");											
		
			pers = creazionePersona ( atoi (persone), pianoAttuale, atoi (strtok (NULL, "/") ) );
											// Aggiungo una persona alla lista dell'ascensore.
			if ( pers -> iPeso == 100) {	// Implementazione della precedenza in favore dell'addetto alla manutenzione.

				aggiungiAllaLista(pers -> iPeso, pianoAttuale, pers -> iPianoDestinazione,  false);
		
			} else {	

				aggiungiAllaLista(pers -> iPeso, pianoAttuale, pers -> iPianoDestinazione, true);
			
		}

		sprintf(arrayDati, "[SALITO A BORDO] %s, %s, piano %d, destinazione %d\n", conversionePeso(pers -> iPeso), dataEora(), pianoAttuale, pers -> iPianoDestinazione); // Scrittura nel log di chi è salito a bordo.
		scriviSuFile(nomeDelFileDiLog, arrayDati);	// Scrittura nel log della fermata.
		contPersoneAggiunte++;																	
	
	}

	return contPersoneAggiunte;	// Ritorno il numero di persone inserite nella lista dell'ascensore.

}

void richiestaDiConnessione ( char *comando ) {
	
	int pianiConnessi = 0;	// Numero di piani alla quale è stato inviato il messaggio di connessione.
	char buffer[20];
	int risultatoClose = 0;
		
	while ( pianiConnessi < 4 ) {
		
		do {

			clientFd = socket (AF_UNIX, SOCK_STREAM, DEFAULT_PROTOCOL);
			
			if ( clientFd == -1 ) {

				printf("\nErrore nella creazione del socket\n");
				sleep(1);
				
			}

		} while (clientFd == -1);

		sprintf(arrayDati, "socket/piano%d", pianiConnessi);	// Mi connetto iterativamente con ogni Piano/Server.
		
		serverUNIXAddress.sun_family = AF_UNIX; 									
		
		strcpy(serverUNIXAddress.sun_path, arrayDati); 		// Viene posto il nome del Piano/Server a cui l'ascensore si deve connettere.
		
		sprintf(arrayDati, "\nIn attesa di connessione con il Piano/Server --> %s\n", serverUNIXAddress.sun_path);
		
		printf("%s\n", arrayDati);
	
		do { // Tentativo di connessione col Piano/Server	
			
			risultatoFunzione = connect(clientFd, serverSockAddrPtr, serverLen);				
			
			if (risultatoFunzione == -1) {

				sleep (1);
				printf("\nConnessione in corso\n");															
			
			}
			
		} while (risultatoFunzione == -1);													
	
		printf("\nConnessione Riuscita\n");
		
		sprintf(buffer, "%s", comando);	// Scrivo il messaggio da inviare al socket.
		
		risultatoFunzione = write(clientFd, buffer, strlen(buffer) + 1); // Scrivo sul socket il messaggio.

		controlloWrite(risultatoFunzione);

		risultatoClose = close (clientFd);

		controlloClose(risultatoClose);

		pianiConnessi++;
	
	}
	
}

void gestoreInterruzioneForzata (int signal) {

	char ID[20];
	printf("\nL'applicazione è stata interrotta dall'utente\n");
	sprintf(ID, "elevator\ntermina\n");										// Identificazione ascensore con richiesta di terminare tutto.
	richiestaDiConnessione(ID);												// Spedizione del messaggio a tutti i piani di terminarsi.
	totalePersoneTrasportate(nomeDelFileDiLog);								// Conteggio finale delle persone.
	stampaLogSulTerminale (nomeDelFileDiLog);
	exit(EXIT_SUCCESS);

}

int main ( int argc, char *argv[] ) {

	int risultatoClose = 0;
	char ID[20];
	serverSockAddrPtr = (struct sockaddr*) &serverUNIXAddress;
	serverLen = sizeof (serverUNIXAddress);

	if ( argc < 2 || argc > 2 ) { // Controllo sintattico sul lancio dell'applicazione.

		sprintf(arrayDati,"\nErrore sintattico durante il lancio dell'applicazione. Sintassi: elevator minuti\n");
		printf("%s\n", arrayDati);
		exit(EXIT_FAILURE);
																	
	}

	tempoRimasto = atoi(argv[1]) * 60;	// Trasformazione di una stringa in un intero tramite atoi.

	sprintf(arrayDati, "\nL'ascensore è stato avviato per %d secondi\n", tempoRimasto);
	printf("%s\n", arrayDati);

	sprintf(nomeDelFileDiLog, "%s", "logs/logElevator.txt");	// Inizializzazione del file log dell'ascensore; Pathname - Scrittura Intestazione										
	
	inizializzazioneFileDiLog(nomeDelFileDiLog);

	sprintf(arrayDati, "\n%s\n\n", dataEora());
	scriviSuFile(nomeDelFileDiLog, arrayDati);	// Scrittura di data e ora sul log.
		
	sprintf(ID, "elevator\ninizio\n");	// Idetificazione dell'ascensore con richiesta di iniziare conteggio del tempo.
	richiestaDiConnessione(ID);	// Invio il messaggio (per fare la connessione) a tutti i piani di iniziare il tempo.
	
	tempoTrascorso();																	// Inizializzazione del tempo dell'ascensore.
	
	pidProcesso = fork ();	// Ho bisogno di duplicare il processo:
						// Il figlio si occupa della connessione coi server ed il padre dell'ascensore ( gestione durata applicazione ).
	if ( pidProcesso == 0 ) {	// Codice del figlio.
		// Il figlio si occupa della comunicazione con il piano/Server.
		int numeroPianiDaPercorrere = 0;		
		bool mostraSulTerminale = true;			// Boleano che controlla la stampa sul terminale.
		
		while (true) {
			
			do {

				clientFd = socket (AF_UNIX, SOCK_STREAM, DEFAULT_PROTOCOL);		// Creazione del socket per comunicare con i Server/Piani.

				if ( clientFd == -1) {

					printf("\nErrore nella creazione del Socket\n");
					sleep(1);

				}

			} while ( clientFd == -1 );
		
			sprintf (arrayDati, "socket/piano%d", pianoAttuale);						// Connessione coi Piani/Server.
			serverUNIXAddress.sun_family = AF_UNIX; 								
			strcpy(serverUNIXAddress.sun_path, arrayDati); 							// Fornisco il nome del server alla quale mi devo collegare.

			if ( mostraSulTerminale == true ) {

				sprintf(arrayDati, "\nConnessione in corso con il Server/Piano %s\n", serverUNIXAddress.sun_path);
				printf("%s\n", arrayDati);

			}
		
			do { // Connessione al Server/Piano.

				risultatoFunzione = connect(clientFd, serverSockAddrPtr, serverLen);

				if (risultatoFunzione == -1) {
					sleep (1);														
				}

			}  while (risultatoFunzione == -1);												
		
			printf("\nL'ascensore si sta muovendo...\n");
						
			// L'ascensore comunica peso ai piani e riceve le persone che devono entrare.
			sprintf(ID, "elevator\n%d\n",(400 - pesoTotaleDellaLista()));				// Identificazione ascensore con un certo peso.
			risultatoFunzione = write(clientFd, ID, strlen(ID) + 1); 						// Scrittura sul socket di ascensore con peso.

			controlloWrite(risultatoFunzione);
		
			risultatoFunzione = aggiungiPersona(clientFd); // Leggo dal socket e aggiungo alla lista dell'ascensore le persone.
			
			if ( mostraSulTerminale == true ) {

				sprintf(arrayDati, "\nSono state inserite %d persone nella lista dell'ascensore \n", risultatoFunzione);
				printf("%s\n", arrayDati);

			}
		
			risultatoClose = close(clientFd);

			controlloClose(risultatoClose);
												// Spostamento ad un nuovo piano.
			pers = prendiLaPrimaPersona();	// Prendo la prima persona (ordine FIFO).

			if ( mostraSulTerminale == true ) {

				sprintf(arrayDati, "\nOra l'ascensore è al piano %d\n", pianoAttuale);
				printf("%s\n", arrayDati);

			}

			if( pers != NULL ) { // Se c'e' qualcuno che deve salire sull'ascensore.

				numeroPianiDaPercorrere = abs(pianoAttuale - pers -> iPianoDestinazione);	// Differenza fra piano attuale e quello prossimo.
			
				if ( numeroPianiDaPercorrere != 0 ) {

					sprintf(arrayDati,"\nDal piano %d l'ascensore sta per andare al %d quindi avviene uno spostamento di %d piani\n", pianoAttuale, pers -> iPianoDestinazione, numeroPianiDaPercorrere);
					printf("%s\n", arrayDati);
														
					sleep (3 * numeroPianiDaPercorrere);	// Mi sposto al nuovo piano (in ogni piano l'ascensore deve sostarvi 3 secondi).
					
					pianoAttuale = pers -> iPianoDestinazione;	// Il piano d'arrivo della persona diventa adesso il suo piano attuale.
			
					sprintf(arrayDati, "\nL'ascensore è arrivato al piano %d\n", pianoAttuale);
					printf("%s\n", arrayDati);
			
					sprintf(arrayDati, "[FERMATA] piano %d, %s\n", pianoAttuale, dataEora()); // Scrivo la fermata sul file di log.
					scriviSuFile(nomeDelFileDiLog, arrayDati);				
			
					sleep(3);	// Tempo di sosta al piano come indicato dalle specifiche.
								
					eliminaDalSistema (pianoAttuale, nomeDelFileDiLog);	// Discesa delle persone dall'ascensore ed eliminazione dal sistema.
				
				}	

				mostraSulTerminale = true;
			
			} else {	// Non c'è gente che vuole salire sull'ascensore.
				
				sleep(1);	// Attesa.															
				mostraSulTerminale = false;
			
			}
				
		}
	
	} else {	// Il padre gestisce il tempo dell'ascensore.
		
		signal(SIGINT, gestoreInterruzioneForzata);

		while ( tempoTrascorso() < tempoRimasto ) {		// Attesa del tempo di terminazione.
			sleep(1);															
		}
		
		sprintf(arrayDati,"\n%s\n", dataEora());		// Data e Ora scritti sul file di log.
		scriviSuFile(nomeDelFileDiLog, arrayDati);		// Scrivo sul log la fermata.
		
		kill(pidProcesso, SIGKILL);		// Eliminazione del processo figlio.
		
		sprintf(arrayDati,"\n\nTempo Applicazione Ascensore Terminato\n");
		printf("%s\n", arrayDati);
		
		sprintf(ID, "elevator\ntermina\n");	// Identificazione ascensore con richiesta di terminare tutto.
		richiestaDiConnessione(ID);			// Spedizione del messaggio a tutti i piani di terminarsi.
		
		totalePersoneTrasportate(nomeDelFileDiLog);	// Conteggio finale delle persone.
		stampaLogSulTerminale (nomeDelFileDiLog);	// Stampa sul terminale il log.

	}
	
	exit(EXIT_SUCCESS);
	
}